"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const config_1 = require("../../config");
const namoUrlProvider_1 = require("./namoUrlProvider");
class UrlEntryProviderFactory {
    static create(provider = config_1.default.DATA_PROVIDER) {
        if (provider === config_1.default.DATA_PROVIDER_AWS) {
            return new namoUrlProvider_1.default();
        }
        else if (provider === config_1.default.DATA_PROVIDER_LOCAL_DYNAMODB) {
            return new namoUrlProvider_1.default({ endpoint: config_1.default.LOCAL_DYNAMODB_ENDPOINT });
        }
        else {
            throw new Error(`Unsupported data provider: '${provider}'`);
        }
    }
}
exports.default = UrlEntryProviderFactory;
;
