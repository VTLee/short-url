"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
const nodenamo_1 = require("nodenamo");
const config_1 = require("../../../config");
let NodenamoUrlEntry = class NodenamoUrlEntry {
    constructor({ id, owner, target, enabled, createdTimestamp, modifiedTimestamp } = {}) {
        this.id = id;
        this.owner = owner;
        this.target = target;
        this.enabled = enabled;
        this.createdTimestamp = createdTimestamp;
        this.modifiedTimestamp = modifiedTimestamp;
    }
};
__decorate([
    nodenamo_1.DBColumn({ id: true }),
    __metadata("design:type", String)
], NodenamoUrlEntry.prototype, "id", void 0);
__decorate([
    nodenamo_1.DBColumn({ hash: true }),
    __metadata("design:type", String)
], NodenamoUrlEntry.prototype, "owner", void 0);
__decorate([
    nodenamo_1.DBColumn(),
    __metadata("design:type", String)
], NodenamoUrlEntry.prototype, "target", void 0);
__decorate([
    nodenamo_1.DBColumn(),
    __metadata("design:type", Boolean)
], NodenamoUrlEntry.prototype, "enabled", void 0);
__decorate([
    nodenamo_1.DBColumn(),
    __metadata("design:type", String)
], NodenamoUrlEntry.prototype, "createdTimestamp", void 0);
__decorate([
    nodenamo_1.DBColumn({ range: true }),
    __metadata("design:type", Object)
], NodenamoUrlEntry.prototype, "modifiedTimestamp", void 0);
NodenamoUrlEntry = __decorate([
    nodenamo_1.DBTable({ name: config_1.default.TABLE_NAME }),
    __metadata("design:paramtypes", [Object])
], NodenamoUrlEntry);
exports.default = NodenamoUrlEntry;
