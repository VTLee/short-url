"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const urlEntryProviderFactory_1 = require("./providers/urlEntryProviderFactory");
class UrlEntryRepository {
    constructor(provider = urlEntryProviderFactory_1.default.create()) {
        this.provider = provider;
    }
    add(entry) {
        return __awaiter(this, void 0, void 0, function* () {
            console.log("Add called");
            return yield this.provider.add(entry);
        });
    }
    get(filter) {
        return __awaiter(this, void 0, void 0, function* () {
            console.log("get called");
            return yield this.provider.get(filter);
        });
    }
    getOne(id) {
        return __awaiter(this, void 0, void 0, function* () {
            console.log("GetOne called");
            return yield this.provider.getOne(id);
        });
    }
    // async update(updatedEntry: IUrlEntry): Promise<void> {
    //     return;
    // }
    delete(shortUrl) {
        return __awaiter(this, void 0, void 0, function* () {
            return yield this.provider.delete(shortUrl);
        });
    }
}
exports.default = UrlEntryRepository;
