"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class Config {
}
exports.default = Config;
Config.AWS_DEFAULT_REGION = 'us-east-1';
Config.DATA_PROVIDER_AWS = 'aws';
Config.DATA_PROVIDER_LOCAL_DYNAMODB = 'local_dynamodb';
Config.DATA_PROVIDER_LIST = [Config.DATA_PROVIDER_AWS, Config.DATA_PROVIDER_LOCAL_DYNAMODB];
Config.DATA_PROVIDER = process.env.LIVE_DATA_PROVIDER || Config.DATA_PROVIDER_AWS;
// Database
Config.TABLE_NAME = process.env.TABLE_NAME || "table-name-nn-one";
Config.LOCAL_DYNAMODB_ENDPOINT = 'http://localhost:8000';
// Misc
Config.API_REQUEST_TIMEOUT_IN_MS = Number(process.env.API_REQUEST_TIMEOUT_IN_MS) || 3000;
Config.DYNAMODB_MAX_RETRIES = Number(process.env.DYNAMODB_MAX_RETRIES) || 3;
Config.DYNAMODB_CONNECT_TIMEOUT_IN_MS = Number(process.env.DYNAMODB_CONNECT_TIMEOUT_IN_MS) || 5000;
Config.DYNAMODB_SOCKET_TIMEOUT_IN_MS = Number(process.env.DYNAMODB_SOCKET_TIMEOUT_IN_MS) || 7000;
;
