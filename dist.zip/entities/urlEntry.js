"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var crypto = require('crypto');
class UrlEntry {
    constructor({ id, owner, target, enabled, createdTimestamp, modifiedTimestamp } = {}) {
        this.id = id || UrlEntry.generateRandomBase32String(5);
        this.owner = owner;
        this.target = target;
        this.enabled = enabled;
        this.createdTimestamp = createdTimestamp;
        this.modifiedTimestamp = modifiedTimestamp;
    }
    static fromJson(obj) {
        if (obj === undefined)
            return undefined;
        return new UrlEntry(obj);
    }
    static generateRandomBase32String(codeLength) {
        let base32 = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
        let code = "";
        let nowInMs = (new Date()).getTime();
        for (let i = 0; i < codeLength; i++) {
            code += base32.charAt(Math.floor(Math.floor(Math.random() * nowInMs) % 32));
        }
        return code.toLowerCase();
    }
}
exports.default = UrlEntry;
;
// async function main() {
//     let ue = new UrlEntry(undefined, 'me');
//     console.log(`${JSON.stringify(ue.shortUrl)}`);
// }
// main().then(() => console.log("done")).catch((e) => console.log(e));
