"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class UrlEntryFilter {
    constructor({ id, owner } = {}) {
        this.id = id;
        this.owner = owner;
    }
    static create(event) {
        let getParam = (name) => name in event.params && event.params[name] ? event.params[name] : undefined;
        let id = getParam('id');
        let owner = getParam('owner');
        return new UrlEntryFilter({ id, owner });
    }
}
exports.default = UrlEntryFilter;
;
