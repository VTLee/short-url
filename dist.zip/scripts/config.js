"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class Config {
}
exports.default = Config;
Config.TABLE_NAME = 'table-name-nn-one';
Config.DYNAMODB_ENDPOINT = process.env.DYNAMODB_ENDPOINT || 'http://localhost:8000';
;
