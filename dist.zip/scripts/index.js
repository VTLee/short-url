"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const urlEntry_1 = require("../entities/urlEntry");
const namoUrlProvider_1 = require("../repository/providers/namoUrlProvider");
const urlEntryFilter_1 = require("../entities/urlEntryFilter");
function main() {
    return __awaiter(this, void 0, void 0, function* () {
        process.env.TABLE_NAME = 'table-name-nn-one';
        let ue = new urlEntry_1.default({ owner: 'me' });
        //var nodenamo:NodeNamo = new NodeNamo(new DocumentClient({ region: 'us-east-1' }))
        //await nodenamo.createTable().for(NodenamoUrlEntry).execute().catch((e) => { /*console.log(e.message)*/ }).catch((e) => { console.log(e) });
        //nodenamo = null;
        let nnp = new namoUrlProvider_1.default({ region: 'us-east-1' });
        let shortUrl = 'vacr'; //UrlEntry.generateRandomBase32String(5);
        let urlentry = new urlEntry_1.default({
            id: shortUrl, owner: 'me', target: 'https://virginiacyberrange.org/', enabled: true,
            createdTimestamp: new Date().toISOString(), modifiedTimestamp: new Date().toISOString(),
        });
        yield nnp.add(urlentry);
        console.log(yield nnp.getOne(urlentry.id));
        let filter = new urlEntryFilter_1.default({ owner: urlentry.owner });
        console.log(yield nnp.get(filter));
    });
}
exports.main = main;
main().catch((e) => { console.log(e); });
