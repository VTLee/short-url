"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const configurapi_1 = require("configurapi");
const urlEntryManager_1 = require("../managers/urlEntryManager");
function checkForGetHandler(event, urlEntryManager) {
    return __awaiter(this, void 0, void 0, function* () {
        this.emit(JSON.stringify(event));
        console.log(JSON.stringify(event));
        if (event.request.path.lastIndexOf('/') > 0) {
            return this.continue();
        }
        let target = event.request.path.substr(1);
        console.log(`Lookup for ID ${target}`);
        let um = new urlEntryManager_1.default();
        let result = yield um.getOne(target);
        console.log(`Result: ${JSON.stringify(result)}`);
        event.request.method = 'get_v1_test';
        event.request.headers['OVERRIDE_RESPONSE'] = new configurapi_1.Response(undefined, 301, { Location: result.target });
        return this.complete();
    });
}
exports.checkForGetHandler = checkForGetHandler;
;
/*
{
    "id": "1ab568e6-362b-4404-a6de-0ce8e626271e",
    "correlationId": "b8aa7d7b-1544-4ad5-8c40-88876c4c9a89",
    "versionRegExp": {},
    "params": {
        "test": ""
    },
    "name": "list_test",
    "request": {
        "method": "get",
        "headers": {
            "host": "simple-api.myntan.com",
            "user-agent": "curl/7.58.0",
            "x-amzn-trace-id": "Root=1-5dacad82-12a6573bf43c9074d3d1aab6",
            "x-forwarded-for": "71.63.60.109",
            "x-forwarded-port": "443",
            "x-forwarded-proto": "https"
        },
        "params": {},
        "payload": "",
        "query": {},
        "path": "/test",
        "pathAndQuery": "/test"
    },
    "response": {
        "statusCode": 200,
        "body": "",
        "headers": {}
    },
    "payload": "",
    "method": "list"
}
*/ 
