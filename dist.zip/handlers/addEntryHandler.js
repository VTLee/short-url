"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const configurapi_1 = require("configurapi");
const urlEntryManager_1 = require("../managers/urlEntryManager");
const urlEntry_1 = require("../entities/urlEntry");
function addEntryHandler(event, urlEntryManager) {
    return __awaiter(this, void 0, void 0, function* () {
        this.emit(JSON.stringify(event));
        console.log(JSON.stringify(event));
        let urlEntry = new urlEntry_1.default(event.payload['target']);
        let um = new urlEntryManager_1.default();
        if (!urlEntry.target) {
            event.response = new configurapi_1.ErrorResponse(`No target given`, 400);
            return;
        }
        console.log(JSON.stringify(urlEntry));
        urlEntry.owner = 'me';
        yield um.add(urlEntry);
        event.response = new configurapi_1.Response(`Response: ${JSON.stringify(event)}`, 200);
    });
}
exports.addEntryHandler = addEntryHandler;
;
